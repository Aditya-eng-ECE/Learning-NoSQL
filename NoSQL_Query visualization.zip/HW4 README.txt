HW4 README
Submitted by - Aditya Kamlesh Dhabekar

In Q.1 I have inserted co-ordinates of all of my sample locations from HW3 and the co-ordinates of Tommy Trojan.

Q.1 Query - { "popularity": { $gte:50 } }

Q.3 Query - {"loc":{"$geoWithin":{"$box":[[34.02191910076206,-118.28662459246014], [34.031776656481114,-118.2830918305793]]}}}

Q.5 HW4 Query -  

{
  loc: {
    $geoWithin: {
      $polygon: [
        [-118.28543902578475,34.02227919290311],
        [-118.28685315013107,34.01963676300529],
        [-118.28401096012922,34.01989316531444]
      ]
    }
  }
}

Q.6 Query - 

{"geometry":{"$geoWithin":{"$box": [ [-169.45380760526996, -14.239727732693918], [-105.69838532231373, 70.0]]}}}